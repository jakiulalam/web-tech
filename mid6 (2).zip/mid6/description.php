<?php
	session_start();
	
	if($_SESSION['abc'])
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);
		
	}else{
		header("location: login.php");

	}
	
?>


<html>
<head>
<title>package Type</title>
</head>
<body>
  <h1><b><u>Cox's Bazar:</b></u></h1>
  
  <h2>Inani beach</h2> <p>(Ukhia Thana,Coxs Bazar,Bangladesh):</p>
 
Inani Beach  is an 18-kilometre-long  sea beach in Ukhia Upazila of Cox'sBazar District,Bangladesh. It has a nice view having a lot of coral stone. This coral stones look green and live in summer or in rainy season. But if someone want to enjoy to look a lot of coral stone then one should go there in winter.<br/>

<img src="inani.jpg" width="550px" height="309px" /><br/>

<h2>Laboni beach</h2> <p>(Laboni Point, Cox's Bazar Beach,Bangladesh):</p>

Laboni Beach is the main beach of Cox's Bazar. At here we can easily enjoy the scenic beauty of Bay of Bengal. Its a place for enjoyment, many people come here including the foreigners. The beach is well appreciated during sunsets and sunrise, where people can witness the sea as it changes its colors twice in a day.Visitors can sunbathe, surf, jog, cycle, and swim. It is best for swimming and relaxation.Close to the beach, there are a lot of small shops selling souvenirs, locally made cigars & beauty products , handmade clothes, bed sheets, dresses, shoes and beach accessories to the tourists.It is a nice place for our tourism. So, come &lets enjoy the beauty of Laboni Beach.<br/>

<img src="Laboni.jpg" width="550px" height="309px" /><br/>

</body>
</html




