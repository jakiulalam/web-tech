





<?php
	error_reporting(0);
	function checkAscii($input){
		$flag=0;
		$inputArray = str_split( $input);
  
		for( $i=0 ; $i < strlen($input) ; $i++ ){
			if( (ord($inputArray[$i]) >= 97 && ord($inputArray[$i]) <= 122) || ord($inputArray[$i]) == 32 || (ord($inputArray[$i]) >= 65 && ord($inputArray[$i]) <=90) ){
				$flag++;
			}
		}
		if( $flag == strlen($input) && $inputArray[0] != "." && $inputArray[0] != "-"){
			return true ;
		}
		else{
			return false;
		}
    }
    
	function checkName($username){
		if(strlen($username) >=2 && checkAscii($username)){
			
			return true;
		}else{
			return false;
		}
    }
    
	function checkEmail($email){
		$flag=0;
		$inputArray = str_split( $email);
		$findme   = '@';
    $findme2 =".";
		$pos = strpos($email, $findme);
    $pos2 = strpos($email, $findme2);
  
	  if( ($inputArray[0] != "@" || $inputArray[0] != "." || $inputArray[$pos+1] != "." ) && ($pos && $pos2)) {
		return true;
	  }else{
		return false;
	}
        }
		
		
		
		
		
		
		
		if( isset($_POST['submit'])){
		if( $_POST['username']== "" || $_POST['email']=="" || $_POST['password']=="" ){
			header("location: registration.php?status=nullvalue");
		}
		else{
				if( checkName( $_POST['username']) && checkEmail($_POST['email'])){

					$username 		= $_POST['username'];
					$email 		= $_POST['email'];
					$password 		= $_POST['password'];
					$url 		= $_POST['url'];
				$address		= $_POST['address'];
					
				
				
			
                    

                    $myfile = fopen("user.txt", 'a');
			        $data = $username."|".$email."|".$password."|".$url."|".$address."\r\n";
			        fwrite($myfile, $data);
                    fclose($myfile);
                    
			        header("location: login.php");
					
				}
				else{
					
								header("location: registration.php?status=Error");
					
				}
				
				
		}
	
	}
	else{
		echo "Invalid request";
	}
		
		
		
	
	if(isset($_POST['reset'])){

		
		header("location: reg.php");
		
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
        
	?>	
		