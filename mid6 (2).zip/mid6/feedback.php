<?php
	session_start();
	
	if($_SESSION['abc'])
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);
		
	}else{
		header("location: login.php");

	}
	
?>
<html>
<head>
<title>Feedback</title>
</head>
<body>
<form>
<center>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="40"> Customer Feedback</td>
</tr>
<tr>
<td colspan="2"  height="30"> 
<input type="button" name="back" value="back" onclick="window.location.href='home.php'">
</td>
</tr>
<tr>
<td>  User Name: </td>
<td> <input type="text" name="name" value="Niloy"></td>
</tr>
<tr>
<td> Email: </td>
<td> <input type="text" name="duration" value="niloy@gmail.com"></td>
</tr>
<tr>
<td> Address: </td>
<td> <input type="text" name="destination" value="Uttara"></td>
</tr>
<tr>
<td> Feedback: </td>
<td> <input type="text" name="cost"value="Overall satisfactory"></td>
</tr>
</center>
</form>
</body>
</html
