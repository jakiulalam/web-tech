<?php


?>
<fieldset>
<legend>Form</legend>
<form method="post" action="regCheck.php"

<html>

<head>

<title>Registration</title>


</head>
<body>
<table border="1" width="500px"height="100px">
<tr align="center">
<td colspan="2">
<h3>Person profile</h3>

</td>
</tr>

<tr>
<td>Name</td>
<td>
<input type="text" name="" value="">*
</td>

</tr>


<tr>

<td>Email</td>
<td ><input type=""text" name="" value="">*</td>

</tr>


<tr>

<td>Password</td>
<td ><input type="password" name="" value="">*</td>

</tr>


<tr>
<td>Gender</td>
<td>
<input type="radio">Male</input>
<input type="radio">Female</input>
<input type="radio">other *</input>

</td>


</tr>


<tr>
<td>Date of birth</td>
<td><input type="text" name="" value="" size="3px">/

<input type="text" name="" value="" size="3px">/
<input type="text" name="" value="" size="3px">(dd/mm/yy)*
</td>
</tr>

<tr>
<td>Blood grp</td>
<td>
<select>

<option selected value="A+">A+</option>
<option value="B+">B+</option>
<option value="o+">O+</option>
<option value="A-">A-</option>
<option value="B-">B-</option>
<option value="O-">O-</option>
<option value="AB+">AB+</option>
<option value="AB_">AB-</option><option value="o+">o+</option>

</select>
</td>



</tr>

<tr >

<td >Address</td>
<td>
<textarea name="comment" rows="3" cols="20"></textarea>

</tr>

<tr>
<td colspan="3" width="500px" height="50px" align="right"valign="bottom">
<input type="button" name="" value="submit">
<input type="button" name="" value="reset">
</td>
</tr>


</table>

</fieldset>
</body>


</form>