<?php
	session_start();
	
	if($_SESSION['abc'])
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);
		
	}else{
		header("location: login.php");

	}
	
?>



<html>
<head>
<title>Payment</title>
</head>
<body>
<form>
<center>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="80" >Payment</td>
</tr>
<tr>
<td colspan="2"  height="30"> 
<input type="button" name="back" value="back" onclick="window.location.href='home.php'">
</td>
</tr>
<tr>
<td>  <img src="im1.jpg" width="160" height="80" /> </td>
<td>Bkash Mobile No:-01770751986 </td>
</tr>
<tr>
<td> <img src="im2.jpg" width="160" height="80" /></td>
<td>Rocket Mobile No:-01521207843 </td>
</tr>

</center>
</form>
</body>
</html



