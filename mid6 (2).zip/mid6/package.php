<?php
	session_start();
	
	if($_SESSION['abc'])
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);
		
	}else{
		header("location: login.php");

	}
	
?>

<html>
<head>
<title>Package</title>
</head>
<body>
<form>
<center>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="40"> Package Info</td>
</tr>
<tr>
<td colspan="2"  height="30"> 
<input type="button" name="back" value="back" onclick="window.location.href='home.php'">
</td>
</tr>
<tr>
<td>  Agenci Name: </td>
<td> <input type="text" name="name" value="Nila Agency"></td>
</tr>
<tr>
<td> Duration: </td>
<td> <input type="text" name="duration" value="2 Nights 3 Days"></td>
</tr>
<tr>
<td> Destination: </td>
<td> <input type="text" name="destination" value="Bandarban"></td>
</tr>
<tr>
<td> Cost: </td>
<td> <input type="text" name="cost"value="TK:5500/=(pp)"></td>
</tr>
<tr>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="40"> Package Info</td>
</tr>

<tr>
<td>  Agenci Name: </td>
<td> <input type="text" name="name" value="romania Agency"></td>
</tr>
<tr>
<td> Duration: </td>
<td> <input type="text" name=""value="3 Nights 4 Days"></td>
</tr>
<tr>
<td> Destination: </td>
<td> <input type="text" name="destination" value="Cox's Bazar"></td>
</tr>
<tr>
<td> Cost: </td>
<td> <input type="text" name="cost"value="TK:7500/=(pp)"></td>
</tr>
</tr>
<tr>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="40"> Package Info</td>
</tr>

<tr>
<td>  Agenci Name: </td>
<td> <input type="text" name="name"value="romania Agency"></td>
</tr>
<tr>
<td> Duration: </td>
<td> <input type="text" name="duration"value="4 Nights 5 Days"></td>
</tr>
<tr>
<td> Destination: </td>
<td> <input type="text" name="destination"value="Sylhet"></td>
</tr>
<tr>
<td> Cost: </td>
<td> <input type="text" name="cost"value="TK:9500/=(pp)"></td>
</tr>
</tr>
<tr>
<td colspan="2"  height="30"> 
[N.B:Child policy:Under 3 years free and under 7 years 50%]
</td>
</tr>
</center>
</form>
</body>
</html







