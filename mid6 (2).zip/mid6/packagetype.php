<?php
	session_start();
	
	if($_SESSION['abc'])
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);
		
	}else{
		header("location: login.php");

	}
	
?>

<html>
<head>
<title>package Type</title>
</head>
<body>
<form>
<center>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="40">Tour Type</td>
</tr>
<tr>
<td colspan="2"  height="30"> 
<input type="button" name="back" value="back" onclick="window.location.href='home.php'">
</td>
</tr>
<tr>
<td>  Domestic: </td>
<td>Sylhet, Coxbazar, Bandarban. </td>
</tr>
<tr>
<td> International:</td>
<td>Nepal, India. </td>
</tr>

</center>
</form>
</body>
</html




