<?php
	session_start();
	
	if($_SESSION['abc'])
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);

		
		echo "logged in as: ".$_SESSION['username']."<br/>";
		
		
		
		
	}else{
		header("location: login.php");

	}
	
?>

<html>
<head>
<title>Home</title>
</head>

<body>
	
	<table align="center" border="1" width="660" height="350"  cellpadding="10" cellspacing="0" >
		
		<tr>
			<td height="30" align="center"><h1>Travel & Tourism</h1></td>
		</tr>
		<tr>
			<td height="20">
				
				<a href="package.php">Provide Package</a>&nbsp &nbsp &nbsp  
				<a href="PackageType.php"> Package Type</a> &nbsp &nbsp &nbsp
				<a href="description.php">Description</a> &nbsp &nbsp &nbsp
				<a href="payment.php">Payment</a> &nbsp &nbsp &nbsp
				
				<a href="profile.php">Profile</a>&nbsp &nbsp &nbsp
				<a href="discount.php">Discount</a>&nbsp &nbsp &nbsp
				<a href="Feedback.php">Feedback</a>
				
			</td>			
		</tr >	
		
		<tr>
				
			<td > <img src="abc.jpg" width="660" height="345" />
		
				
				
			</td>
				
												
		</tr>
		
		<tr height="5">
			<td  valign="top" colspan="2"><center>Copyright 2018</center></td>
		</tr>	
	</table>
</body>

</html>