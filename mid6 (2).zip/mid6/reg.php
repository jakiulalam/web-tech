<fieldset>
<legend>Form</legend>
<form method="post" action="regCheck.php"

<html>

<head>

<title>Registration</title>


</head>
<body>
<table border="1" width="500px"height="100px">
<tr align="center">
<td colspan="2">
<h3>Agency profile</h3>

</td>
</tr>

<tr>
<td>Username</td>
<td>
<input type="text" name="username" value="" required>*
</td>

</tr>


<tr>

<td>Email</td>
<td ><input type=""text" name="email" value="" required>*</td>

</tr>


<tr>

<td>Password</td>
<td ><input type="password" name="password" value="" required>*</td>

</tr>


<tr>
<td>Website</td>
<td ><input type=""text" name="url" value="" ></td>


</tr>






<tr >

<td >Address</td>


<td ><input type=""text" name="address" value=""  rows="3" cols="20"></td>
</tr>

<tr>
<td colspan="3" width="500px" height="50px" align="right"valign="bottom">
<input type="submit" name="submit" value="submit">
<input type="submit" name="reset" value="reset">
</td>
</tr>


</table>

</fieldset>
</body>


</form>
