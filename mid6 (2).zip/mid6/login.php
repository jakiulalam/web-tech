<?php
	
	if(isset($_GET['status'])){
		$status = $_GET['status'];

		if($status == "invaliduser"){
			echo "Invalid user info! try again...";
		}else if($status == "nullvalue"){
			echo "Username/password can't be empty";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<body>

		<fieldset>
			<legend>LOGIN</legend>

			<form method="post" action="logCheck.php">
				
				User Name: <input type="text" name="username"><br/>
				Password : <input type="password" name="password"><br/>
				
						   <input type="submit" name="submit" value="Submit">
						   <a href="reg.php">Register </a>
			</form>
		</fieldset>
</body>
</html>