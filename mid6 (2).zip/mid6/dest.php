
<!DOCTYPE html>
<html>
<head>
<title>Add Travel Agecies</title>
</head>
<body>
<form>
<center>
<table align="center" border="1" cellspacing="1" cellpadding="1" width="50%"height="30%">
<tr align="center" >
<td colspan="2" height="40">Add Travel Agecies</td>
</tr>
<tr>
<td colspan="2"  height="30"> 
<input type="button" name="back" value="back" onclick="window.location.href='home.php'">
</td>
</tr>
<tr>
<td>  Agenci Name: </td>
<td> <input type="text" name="username"></td>
</tr>
<tr>
<td> Name: </td>
<td> <input type="text" name="username"></td>
</tr>
<tr>
<td> Destination: </td>
<td> <input type="text" name="username" value="toto" placeholder="toto" ></td>
</tr>
<tr>
<td> Cost: </td>
<td> <input type="text" name="username"></td>
</tr>
</center>
</form>
</body>
</html




<input type="button" name="back" value="back" onclick="window.location.href='home.php'">