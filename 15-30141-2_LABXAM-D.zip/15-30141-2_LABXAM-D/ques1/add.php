<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>
<html>
<head>
	<title>Add student Data</title>
</head>

<body>
<?php

include_once("connection.php");

if(isset($_POST['Submit'])) {	
	$id=$_POST['id'];
	$sname = $_POST['sname'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$loginId = $_SESSION['id'];
		
	
	if(empty($id) || empty($sname) || empty($username) || empty($password)) {
				
		if(empty($id)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($sname)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($username)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
		if(empty($password)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
		
		
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		
			
		
		$result = mysqli_query($mysqli, "INSERT INTO student(id, sname, username,password, login_id) VALUES('$id','$sname','$username','$password', '$loginId')");
		
		
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='view.php'>View Result</a>";
	}
}
?>
</body>
</html>
