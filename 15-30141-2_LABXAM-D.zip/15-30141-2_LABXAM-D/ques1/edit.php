<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php

include_once("connection.php");

if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	$sname = $_POST['sname'];
	$username = $_POST['username'];
	$password = $_POST['password'];	
	
	
	if(empty($id) || empty($sname) || empty($username) || empty($password)) {
			
          if(empty($id)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
			
		if(empty($sname)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($username)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($password)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}		
	} else {	
		
		$result = mysqli_query($mysqli, "UPDATE student SET sname='$sname', username='$username', password='$password' WHERE id=$id");
		
		
		header("Location: view.php");
	}
}
?>
<?php

$id = $_GET['id'];


$result = mysqli_query($mysqli, "SELECT * FROM student WHERE id=$id");

while($res = mysqli_fetch_array($result))
{   

     $id = $res['id'];
	$sname = $res['sname'];
	$username = $res['username'];
	$password = $res['password'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="view.php">View student</a> | <a href="logout.php">Logout</a>
	<br/><br/>
	
	<form name="form1" method="post" action="edit.php">
		<table border="0">
		   <tr> 
				<td>Id</td>
				<td><input type="text" name="id" value="<?php echo $id;?>"></td>
			</tr>
			<tr> 
				<td>Name</td>
				<td><input type="text" name="sname" value="<?php echo $sname;?>"></td>
			</tr>
			<tr> 
				<td>Username</td>
				<td><input type="text" name="username"></td>
			</tr>
			<tr> 
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
