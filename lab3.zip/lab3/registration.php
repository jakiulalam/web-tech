

<?php


error_reporting(0);
//print_r($_POST);
echo"<br/>";
echo $_POST['name'];
echo "<br/>";
echo  $_POST['email'];
echo "<br/>";
echo  $_POST['gender'];
echo "<br/>";
echo $_POST['Day']."/";

echo $_POST['Month']."/";

echo $_POST['Year']."/";
echo "<br/>";





?>















<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form method="POST" action="#" >
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text" value="<?=$_POST['name'];?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text" value="<?=$_POST['userName'];?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio" value="male"<?php if($_POST['gender']=='male'){echo "checked";}?>>Male
						<input name="gender" type="radio"value="female"<?php if($_POST['gender']=='female'){echo "checked";}?>>Female
						<input name="gender" type="radio"value="other"<?php if($_POST['gender']=='other'){echo "checked";}?>>Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2"name="Day" value="<?=$_POST['Day'];?>"/>/
						<input type="text" size="2" name="Month"/>/
						<input type="text" size="4" name="Year"/>
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" value="Submit">
		<input type="reset">
	</form>
</fieldset>